// lib/api-updates.ts

// Utility function to get date for database
export const getDateForDatabase = () => {
  return new Date().toISOString()
}
